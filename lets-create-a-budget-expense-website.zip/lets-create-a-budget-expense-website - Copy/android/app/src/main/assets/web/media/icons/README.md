# Couple Budget Icon Repository

This folder keeps finance icon sources and local app-ready icons.

## Flaticon source pages

The source links requested for future icon picking are saved in `flaticon-sources.json`.
Flaticon icons can be downloaded as SVG or PNG from the site, but individual assets may require attribution or account/license steps. For that reason, this repository stores the source links and uses original local SVG icons in `custom/` for the app.

## Local icons

PNG folders are available under `png/<category>/` for bulk browsing, and the lightweight custom SVG set is available under `custom/` for direct app use.

- `custom/spending.svg`
- `custom/wallet.svg`
- `custom/money.svg`
- `custom/budget.svg`
- `custom/saving.svg`
- `custom/shopping.svg`

Palette: navy `#08243b`, coral `#ff6655`, green `#4f843d`, gold `#f3b43c`, cream `#fff4df`.
